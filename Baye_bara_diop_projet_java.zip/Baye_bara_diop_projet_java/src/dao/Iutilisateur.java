package dao;

import entity.Utilisateur;

import java.util.List;

public interface Iutilisateur {
    public List<Utilisateur> list();
    public Utilisateur saisir(Utilisateur u);


}
