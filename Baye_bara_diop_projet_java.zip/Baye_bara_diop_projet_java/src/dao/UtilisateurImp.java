package dao;

import entity.Utilisateur;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;


public class UtilisateurImp implements Iutilisateur{
    @Override
    public List<Utilisateur> list() {
        List<Utilisateur> utilisateurs=new ArrayList<Utilisateur>();
        Db db=new Db();
        String sql="Select *from utilisateur u,role r where u.idur=r.idr ";
            try {
                db.initprepar(sql);
                ResultSet rs= db.executequery();
                while (rs.next()){
                    Utilisateur u=new Utilisateur();
                    u.setId(rs.getInt("idu"));
                    u.setEmail(rs.getString("email"));
                    u.setPwd(rs.getString("pwd"));
                    u.setNom(rs.getString("nom"));
                    utilisateurs.add(u);

                }
                db.closeconnexion();

            }catch (Exception e){
                e.printStackTrace();
            }
        return utilisateurs;
    }

    @Override
    public Utilisateur saisir(Utilisateur u) {
            Db db=new Db();
            ResultSet set;
            int ok;
            String sql="INSERT INTO utilisateur VALUES(NULL,?,?,?)";
            try {
                db.initprepar(sql);
                db.getP().setString(1,u.getEmail());
                db.getP().setString(2,u.getPwd());
                db.getP().setInt(3,u.getIdur());
                ok=db.ExecuteMaj();
                db.closeconnexion();
            }catch (Exception e){
                e.printStackTrace();
            }
        return u;
    }



}
