package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class Db {
        private Connection conn;
         private ResultSet rs;
         private PreparedStatement p;
         private int ok;
         private void getConnexion(){
             String url="jdbc:mysql://localhost:3306/dbjava";
             String user="root";
             String password="";
             try {
                 Class.forName("com.mysql.cj.jdbc.Driver");
                 conn=DriverManager.getConnection(url,user,password);

             }catch (Exception e){
                 e.printStackTrace();
             }
         }
         public void initprepar(String sql){
             try {
                 getConnexion();
                 p= conn.prepareStatement(sql);
             }catch (Exception e){
                 e.printStackTrace();
             }
         }
         public ResultSet executequery(){
             rs=null;
             try {
                 rs= p.executeQuery();
             }catch (Exception e){
                 e.printStackTrace();
             }
             return rs;
         }
         public int ExecuteMaj(){
             try {
                int ok=p.executeUpdate();
             }catch (Exception e){
                 e.printStackTrace();
             }
             return ok;
         }
         public void closeconnexion(){
             try {
                    if (conn!=null){
                        conn.close();
                    }
             }catch (Exception e){
                 e.printStackTrace();
             }
         }

    public PreparedStatement getP() {
        return p;
    }
}
