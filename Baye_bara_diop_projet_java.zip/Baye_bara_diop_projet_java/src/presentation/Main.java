package presentation;

import dao.UtilisateurImp;
import entity.Utilisateur;

import java.util.List;
import java.util.Scanner;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
            int a;

        UtilisateurImp u=new UtilisateurImp();
        Utilisateur ut=new Utilisateur();
        Scanner s=new Scanner(System.in);
       do {
           System.out.println("1-Ajouter");
           System.out.println("2-Afficher");

           a=s.nextInt();
           switch (a){
               case 1:
                   System.out.println("donner l'adresse email");
                   s.nextLine();
                   ut.setEmail(s.nextLine());
                   System.out.println("donner le mot de passe");
                   ut.setPwd(ut.cryp(s.nextLine()));
                   do {
                       System.out.println("donner l'utilisateur un profil");
                       System.out.println("1-admin");
                       System.out.println("2-Super Admin");
                       System.out.println("3-utilisateur simple");
                       ut.setIdur(s.nextInt());
                   }while (ut.getIdur()>3);
                   u.saisir(ut);
                   break;
               case 2:
                   List<Utilisateur> utilisateur=u.list();
                   for (Utilisateur utilisateurs:utilisateur){
                       System.out.println("Utilisateur: " +utilisateurs.getId());
                       System.out.println("email : " +utilisateurs.getEmail());
                       System.out.println("mot de passe : " + utilisateurs.getPwd());
                       System.out.println("profil: " + utilisateurs.getNom());
                   }
               default:

           }
       }while (true);
    }
}