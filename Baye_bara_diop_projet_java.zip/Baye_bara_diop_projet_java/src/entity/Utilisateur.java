package entity;

import java.util.Random;

public class Utilisateur {
    private int id;
    private String email;
    private String pwd;
    private String nom;
    private int idur;
    public static String abc="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    public int getId() {
        return id;
    }

    public String getEmail() {
        return email;
    }

    public String getPwd() {
        return pwd;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public int getIdur() {
        return idur;
    }

    public void setIdur(int idur) {
        this.idur = idur;
    }
   public String cryp(String str){
        Random r=new Random();
        String pass=""+r.nextInt(1001,9900);
        for (int i = 0; i < str.length(); i++) {
            char c = str.charAt(i);
            if(c == 'z'){
                pass+= 'a';
            }
            else if(c == 'Z'){
                pass+= 'A';
            } else if (abc.contains(""+c)){
                pass+=abc.charAt(abc.indexOf(c)+1);
            }else{
                pass+=str.charAt(i);
            }
        }
        return pass+r.nextInt(10000,99999);

    }
    public String decrypt(String str){
        String pass = "";
        for (int i = 4; i < str.length()-5; i++) {
            //System.out.println(str.charAt(i));
            char c = str.charAt(i);
            if(c == 'a'){
                pass+= 'z';
            }
            else if(c == 'A'){
                pass+= 'Z';
            }else if (abc.contains(""+c)){
                pass+= abc.charAt(abc.indexOf(c)-1);
            }else{
                pass+=str.charAt(i);
            }
        }
        return pass;
    }


}
